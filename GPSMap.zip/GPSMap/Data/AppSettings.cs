﻿namespace GPSMap.Data
{
    public class AppSettings
    {
        public string Settings { get; set; } = "";
        public string EventHubConnectionString { get; set; } = "";
    }
}
